// ================================================================
// Name: Can't Stop Board Game        Jan, 2025
// Author:  Ashish Khadka and Aryan Tandon      File: enums.hpp
// ================================================================
#pragma once
#include "tools.hpp"
// -----------------------------------------------------------------
enum class ECcolor {White, Yellow, Green, Blue, Orange, Error};
extern const string colorNames[];
