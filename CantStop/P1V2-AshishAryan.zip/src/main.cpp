//=======================================================================
// Project: Can't Stop Board Game        File: main.cpp
// Author:  Ashish Khadka and Aryan Tandon  Copyright: 2025
// ======================================================================
#include "tools.hpp"
#include "Dice.hpp"
// ----------------------------------------------------------------------
void unitDice();

int main(int argc, const char * argv[]) {
    banner();
	srand(time(nullptr)); // Seed the random number generator once
	unitDice();
    bye();
}
